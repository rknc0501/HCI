# Job Stories — Week 6 Needs-Finding

## Story S1: Predictable Focus Order
**Situation**: When I'm navigating a complex form or multistep workflow using the Tab key  
**Motivation**: I want the visual focus order to strictly follow the logical reading order of the content  
**Outcome**: So I can complete the form efficiently and predictably without missing fields or jumping unexpectedly to unrelated sections  
**Underlying need**: inconsistent or unpredictable focus order creates significant cognitive dissonance and frustration, especially for users relying on keyboard-only navigation or screen readers, severely hindering task completion.  

**Evidence**: Participant A (notes L5), Participant B (notes L3)  
**Inclusion risk**: Motor, Cognitive, Screen reader  
**Type**: Job story  
**WCAG**: 2.4.3 Focus Order (A)
---

## Story S2: Confirmation Feedback
**Situation**: When I submit a form (add/edit/delete task)  
**Motivation**: I want immediate, explicit confirmation that the action succeeded  
**Outcome**: So I can trust the interface without refreshing to verify  
**Underlying need**: Because uncertainty about save status causes anxiety and inefficient workarounds  

**Evidence**: Participant A (notes L5)  
**Inclusion risk**: Cognitive, Screen reader, Low digital literacy  
**Type**: Job story  
**WCAG**: 4.1.3 Status Messages (AA)


---

## Story S3: Readable Input Error Messages
**Situation**: When I submit a form and receive an error because of invalid input (e.g., entering letters in a phone number field)  
**Motivation**: I want the error message to be placed immediately adjacent to the failed input field, clearly describing what went wrong and how to fix it  
**Outcome**: So I can pinpoint the error quickly and understand the required corrective action without searching the screen  
**Underlying need**: Because non-specific or remotely located error messages create unnecessary visual and cognitive searching, making remediation difficult and frustrating for all users, particularly those with low vision or screen magnification.

**Evidence**: Support Tickets (Form failure complaints), Participant I (Low vision screen recording)  
**Inclusion risk**: Visual, Cognitive  
**Type**: Job story  
**WCAG**: 3.3.3 Error Suggestion (AA)


---

## Story S4: Text Resizing Support
**Situation**: When I am reviewing detailed documentation or a large data table on my monitor  
**Motivation**: I want to be able to zoom the browser text up to 200% without the content or layout breaking or requiring horizontal scrolling  
**Outcome**: So I can read comfortably with the text size that best suits my visual needs without losing the application's overall context or functionality  
**Underlying need**: Because forced horizontal scrolling or layout overlap makes content unusable, preventing me from accessing critical information if I require higher text magnification.  

**Evidence**: Participant J (Zoom testing results), User Study (Low vision cohort)
**Inclusion risk**: Visual
**Type**: Job story
**WCAG**: 1.4.4 Resize text (AA)

---

## Story S5: Skip to Main Content Link
**Situation**: When I load any new page within the application  
**Motivation**: I want a visible-on-focus link that allows me to bypass repetitive navigation elements, headers, and footers  
**Outcome**: So I can jump directly to the primary information and task area of the page immediately upon loading  
**Underlying need**: Because having to tab through 20+ navigation links and decorative elements on every single page is monotonous, time-consuming, and highly inefficient for keyboard and screen reader users.  

**Evidence**: Accessibility Audit (Screen reader efficiency metrics), Participant K (Keyboard user feedback)
**Inclusion risk**: Motor, Screen reader
**Type**: Job story
**WCAG**: 2.4.1 Bypass Blocks (A)

---
[Write 5-6 total stories based on your interviews]
